<?php

namespace App\Http\Controllers;

use App\Models\Feature;
use Illuminate\Http\Request;
use Cache;

class FeatureController extends Controller
{
    
}
