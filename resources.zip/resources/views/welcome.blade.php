<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<div id="app" class="flex items-center bg-gray-100 ">
    
</div>
<script src="{{ asset('js/app.js') }}"></script>
