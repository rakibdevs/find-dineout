<div class="container mx-auto px-2 pt-5 sm:px-4 lg:px-8">
    <h4 class="bar-title">Available in</h4>
    <zone-list start-point="{{ '/api/fetch/zones/available' }}"></zone-list>
</div>
<footer-component></footer-component>