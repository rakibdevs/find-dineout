<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - </title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
    <!-- loader END -->
    <div id="app">
        <header-component></header-component>
        <div class="main-content">
            
            <?php echo $__env->yieldContent('container'); ?>
        </div>
        <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body><?php /**PATH D:\New folder\find-dineout\resources\views/app.blade.php ENDPATH**/ ?>