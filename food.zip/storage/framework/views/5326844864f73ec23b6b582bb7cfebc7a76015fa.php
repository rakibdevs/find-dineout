<div class="container mx-auto px-2 pt-5 sm:px-4 lg:px-8">
    <h4 class="bar-title">Available in</h4>
    <zone-list start-point="<?php echo e('/fetch/available-zones'); ?>"></zone-list>
</div>
<footer-component></footer-component><?php /**PATH D:\New folder\find-dineout\resources\views/include/footer.blade.php ENDPATH**/ ?>