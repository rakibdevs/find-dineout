<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<div id="app" class="flex items-center bg-gray-100 ">
    <login></login>
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php /**PATH D:\New folder\find-dineout\resources\views/welcome.blade.php ENDPATH**/ ?>