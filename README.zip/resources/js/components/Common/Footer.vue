<template>
	<div class="footer-section pt-3 pb-3">
		<div class="text-center">
			© 2021, foodmoy. All Rights Reserved.
		</div>
	</div>
</template>