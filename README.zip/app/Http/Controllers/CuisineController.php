<?php

namespace App\Http\Controllers;

use App\Models\Cuisine;
use Cache;
use Illuminate\Http\Request;

class CuisineController extends Controller
{
    
}
