<template>
	<div class="animate-pulse">
		<div class="h-4 bg-gray-200 mt-3 mb-6 rounded"></div>
		<div class="h-4 bg-gray-300 mb-6 rounded"></div>
		<div class="h-4 bg-gray-200 mb-6 rounded"></div>
		<div class="h-4 bg-gray-300 mb-6 rounded"></div>
		<div class="h-4 bg-gray-200 mb-6 rounded"></div>
	</div>
</template>