<div class="shadow">
    <div class="container  mx-auto px-2 pt-5 sm:px-4 lg:px-8">
        <h4 class="bar-title">Available in</h4>
        <footer-location start-point="{{ url('/api/fetch/locations/available') }}"></footer-location>
        <footer-component></footer-component>
    </div>
</div>
