@extends('app')
@section('title','Home')
@section('container')
    <div class="flex items-center min-h-screen bg-white dark:bg-gray-900">
        <div class="container mx-auto">
            <login></login>
        </div>
    </div>
@endsection