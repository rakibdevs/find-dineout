@extends('admin.layout')
@section('title', 'Dashboard')
@section('container')
	<dashboard></dashboard>

@endsection